migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  collection.updateRule = "@request.auth.id != \"\""

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  collection.updateRule = null

  return dao.saveCollection(collection)
})
