migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "95pl3edj",
    "name": "cover",
    "type": "url",
    "required": false,
    "unique": false,
    "options": {
      "exceptDomains": null,
      "onlyDomains": null
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  // remove
  collection.schema.removeField("95pl3edj")

  return dao.saveCollection(collection)
})
