migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  collection.createRule = "@request.auth.id != \"\""

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  collection.createRule = null

  return dao.saveCollection(collection)
})
