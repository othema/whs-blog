migrate((db) => {
  const collection = new Collection({
    "id": "90u0fyefm23x27h",
    "created": "2023-02-20 22:22:51.610Z",
    "updated": "2023-02-20 22:22:51.610Z",
    "name": "posts",
    "type": "base",
    "system": false,
    "schema": [
      {
        "system": false,
        "id": "dm00ripn",
        "name": "content",
        "type": "text",
        "required": true,
        "unique": false,
        "options": {
          "min": null,
          "max": null,
          "pattern": ""
        }
      }
    ],
    "listRule": "",
    "viewRule": "",
    "createRule": null,
    "updateRule": null,
    "deleteRule": null,
    "options": {}
  });

  return Dao(db).saveCollection(collection);
}, (db) => {
  const dao = new Dao(db);
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h");

  return dao.deleteCollection(collection);
})
