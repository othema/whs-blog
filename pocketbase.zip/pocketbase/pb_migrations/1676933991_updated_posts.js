migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  // remove
  collection.schema.removeField("dm00ripn")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "vonsxnfc",
    "name": "title",
    "type": "text",
    "required": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "be6844cy",
    "name": "content",
    "type": "editor",
    "required": true,
    "unique": false,
    "options": {}
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("90u0fyefm23x27h")

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "dm00ripn",
    "name": "content",
    "type": "text",
    "required": true,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  // remove
  collection.schema.removeField("vonsxnfc")

  // remove
  collection.schema.removeField("be6844cy")

  return dao.saveCollection(collection)
})
